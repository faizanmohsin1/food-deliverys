let  editcard  = () => {
    let resName= document.getElementById("resName");
    let dishName= document.getElementById("dishName");
    let price= document.getElementById("price");
   
    
}